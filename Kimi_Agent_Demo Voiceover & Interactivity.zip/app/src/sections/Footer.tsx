import { Link } from 'react-router-dom';
import {
  Mail,
  Phone,
  MapPin,
  ExternalLink,
  Zap,
  Shield,
  FileText,
} from 'lucide-react';

const QUICK_LINKS_SETS = [
  [
    { label: 'Home', href: '#home' },
    { label: 'Features', href: '#features' },
    { label: 'AI Demo', href: '#demo' },
    { label: 'Book a Demo', href: '#book-demo' },
  ],
  [
    { label: 'Services', href: '#features' },
    { label: 'Live Demo', href: '#demo' },
    { label: 'Contact', href: '#book-demo' },
    { label: 'Get Started', href: '#home' },
  ],
];

const scrollTo = (href: string) => {
  if (href.startsWith('#')) {
    const el = document.querySelector(href);
    el?.scrollIntoView({ behavior: 'smooth' });
  }
};

export default function Footer() {
  const linkSetIndex = Math.floor(Date.now() / 50000) % QUICK_LINKS_SETS.length;
  const quickLinks = QUICK_LINKS_SETS[linkSetIndex];

  return (
    <footer className="relative border-t border-border bg-card/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">SA</span>
              </div>
              <span className="text-foreground font-semibold">Southwest Automation</span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              AI-powered call and text assistants that handle your scheduling, 
              answer client questions, and keep your calendar full. 
              A proud subsidiary of Forge Logic Design.
            </p>
            <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
              <p className="text-xs text-primary/80">
                Southwest Automation is a sub branch of Forge Logic Design
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => scrollTo(link.href)}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
              <li>
                <Link
                  to="/privacy"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
                >
                  <FileText className="w-3 h-3" />
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">Services</h4>
            <ul className="space-y-3">
              {[
                'AI Call Answering',
                'Text Messaging',
                'Appointment Scheduling',
                'Call Routing',
                'After-Hours Coverage',
              ].map((service) => (
                <li key={service}>
                  <span className="text-sm text-muted-foreground">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="mailto:forgelogicdesign@gmail.com"
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  forgelogicdesign@gmail.com
                </a>
              </li>
              <li>
                <a
                  href="tel:5054808967"
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  (505) 480-8967
                </a>
              </li>
              <li>
                <div className="flex items-start gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4 mt-0.5" />
                  <span>Southwest Region, USA</span>
                </div>
              </li>
            </ul>

            <div className="mt-4 pt-4 border-t border-border">
              <a
                href="mailto:forgelogicdesign@gmail.com"
                className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors"
              >
                <Zap className="w-4 h-4" />
                Forge Logic Design
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Southwest Automation Solutions. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link
              to="/privacy"
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary transition-colors"
            >
              <Shield className="w-3 h-3" />
              Privacy Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
