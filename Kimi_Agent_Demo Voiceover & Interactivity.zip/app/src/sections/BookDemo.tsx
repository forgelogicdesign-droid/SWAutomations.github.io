import { useState, useRef, useEffect } from 'react';
import { Send, CheckCircle, User, Mail, Building, Phone, MessageSquare, Calendar, Copy, Check, ExternalLink } from 'lucide-react';

const HEADLINES = [
  "Ready to Never Miss a Call Again?",
  "Let AI Handle Your Scheduling",
  "Get Your Time Back",
  "Start Answering 24/7",
];

const SUBHEADLINES = [
  "Book a free demo and see how our AI call and text assistant fills your calendar while you focus on your business.",
  "See firsthand how AI-powered scheduling can transform your customer communications.",
  "We'll show you exactly how the AI handles calls, texts, and appointments in real-time.",
];

export default function BookDemo() {
  const [headlineIndex, setHeadlineIndex] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    message: '',
    preferredDate: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const seed = Math.floor(Date.now() / 35000) % HEADLINES.length;
    setHeadlineIndex(seed);

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // Scroll to top of the form area to show the success message
    sectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const copyToClipboard = () => {
    const text =
      `Demo Request from ${formData.name} - ${formData.company}\n\n` +
      `Name: ${formData.name}\n` +
      `Email: ${formData.email}\n` +
      `Company: ${formData.company}\n` +
      `Phone: ${formData.phone || 'Not provided'}\n` +
      `Preferred Date: ${formData.preferredDate || 'Not specified'}\n\n` +
      `Message:\n${formData.message || 'No additional message.'}`;
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    });
  };

  const gmailComposeUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=forgelogicdesign@gmail.com&su=${encodeURIComponent(
    `Demo Request from ${formData.name} - ${formData.company}`
  )}&body=${encodeURIComponent(
    `Name: ${formData.name}\n` +
    `Email: ${formData.email}\n` +
    `Company: ${formData.company}\n` +
    `Phone: ${formData.phone || 'Not provided'}\n` +
    `Preferred Date: ${formData.preferredDate || 'Not specified'}\n\n` +
    `Message:\n${formData.message || 'No additional message.'}`
  )}`;

  if (submitted) {
    return (
      <section id="book-demo" className="relative py-24 sm:py-32">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-8 rounded-2xl bg-card/50 border border-primary/30 text-center">
            <CheckCircle className="w-16 h-16 text-primary mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-foreground mb-4">
              Demo Request Ready to Send!
            </h3>
            <p className="text-muted-foreground mb-6">
              Your demo request has been prepared. Choose how you'd like to send it:
            </p>

            {/* Send via Gmail */}
            <a
              href={gmailComposeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full px-6 py-4 bg-primary text-primary-foreground rounded-xl font-semibold hover:bg-primary/90 transition-colors mb-4 glow-orange-sm"
            >
              <Mail className="w-5 h-5" />
              Send via Gmail
              <ExternalLink className="w-4 h-4" />
            </a>

            {/* Copy info */}
            <button
              onClick={copyToClipboard}
              className="flex items-center justify-center gap-2 w-full px-6 py-3 bg-muted text-foreground rounded-xl hover:bg-muted/80 transition-colors mb-4"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  Copied to clipboard!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copy request details
                </>
              )}
            </button>

            {/* Direct email */}
            <a
              href="mailto:forgelogicdesign@gmail.com"
              className="flex items-center justify-center gap-2 w-full px-6 py-3 border border-border text-muted-foreground rounded-xl hover:text-primary hover:border-primary/30 transition-colors mb-6"
            >
              <Mail className="w-4 h-4" />
              Open default email app
            </a>

            <div className="p-4 rounded-lg bg-background border border-border text-left">
              <p className="text-xs text-muted-foreground mb-2">Your request preview:</p>
              <p className="text-sm text-foreground font-medium">
                Demo Request from {formData.name} - {formData.company}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {formData.email} • {formData.phone || 'No phone'} • {formData.preferredDate || 'No preferred date'}
              </p>
            </div>

            <p className="text-sm text-muted-foreground mt-6 mb-4">
              Or call us directly at{' '}
              <a href="tel:5054808967" className="text-primary hover:underline font-medium">
                (505) 480-8967
              </a>
            </p>

            <button
              onClick={() => {
                setSubmitted(false);
                setFormData({ name: '', email: '', company: '', phone: '', message: '', preferredDate: '' });
              }}
              className="px-6 py-3 bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors"
            >
              Send Another Request
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="book-demo" ref={sectionRef} className="relative py-24 sm:py-32">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {/* Section Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Calendar className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary font-medium">Free Demo</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="text-gradient">{HEADLINES[headlineIndex]}</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              {SUBHEADLINES[headlineIndex % SUBHEADLINES.length]}
            </p>
          </div>

          {/* Contact Info Bar */}
          <div className="flex flex-wrap justify-center gap-6 mb-10">
            <a
              href="mailto:forgelogicdesign@gmail.com"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              <Mail className="w-4 h-4" />
              forgelogicdesign@gmail.com
            </a>
            <a
              href="tel:5054808967"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              <Phone className="w-4 h-4" />
              (505) 480-8967
            </a>
          </div>

          {/* Form */}
          <form
            onSubmit={handleSubmit}
            className="p-6 sm:p-8 rounded-2xl bg-card/50 border border-border backdrop-blur-sm"
          >
            <div className="grid sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                  <User className="w-4 h-4 text-primary" />
                  Full Name *
                </label>
                <input
                  type="text"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  placeholder="John Doe"
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                  <Mail className="w-4 h-4 text-primary" />
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  placeholder="john@company.com"
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                  <Building className="w-4 h-4 text-primary" />
                  Business Name *
                </label>
                <input
                  type="text"
                  name="company"
                  required
                  value={formData.company}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  placeholder="Your Business LLC"
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                  <Phone className="w-4 h-4 text-primary" />
                  Phone Number
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                  placeholder="(505) 480-8967"
                />
              </div>

              <div className="space-y-2 sm:col-span-2">
                <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                  <Calendar className="w-4 h-4 text-primary" />
                  Preferred Demo Date
                </label>
                <input
                  type="date"
                  name="preferredDate"
                  value={formData.preferredDate}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                />
              </div>

              <div className="space-y-2 sm:col-span-2">
                <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                  <MessageSquare className="w-4 h-4 text-primary" />
                  Tell us about your scheduling needs
                </label>
                <textarea
                  name="message"
                  rows={4}
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none"
                  placeholder="How many calls do you get per week? Do you currently miss calls after hours?"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-6 flex items-center justify-center gap-2 px-8 py-4 bg-primary text-primary-foreground rounded-xl font-semibold hover:bg-primary/90 transition-all glow-orange-sm"
            >
              <Send className="w-4 h-4" />
              Book a Demo
            </button>

            <p className="text-center text-xs text-muted-foreground mt-4">
              By submitting, you agree to our{' '}
              <a href="/privacy" className="text-primary hover:underline">
                Privacy Policy
              </a>
              . We'll never share your information.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}
