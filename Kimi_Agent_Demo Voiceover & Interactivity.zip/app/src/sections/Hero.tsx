import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Phone, MessageSquare, CalendarCheck, Zap } from 'lucide-react';

const TAGLINES = [
  "Your AI Receptionist Never Sleeps",
  "Answer Every Call, Every Text, Every Time",
  "Smart Scheduling Powered by AI",
  "Never Miss Another Appointment",
];

const STATS = [
  { value: "10K+", label: "Calls Handled" },
  { value: "98%", label: "Answer Rate" },
  { value: "24/7", label: "Always On" },
  { value: "3x", label: "More Bookings" },
];

export default function Hero() {
  const [currentTagline, setCurrentTagline] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const seed = Math.floor(Date.now() / 30000) % TAGLINES.length;
    setCurrentTagline(seed);
    setIsVisible(true);
  }, []);

  const scrollToBookDemo = () => {
    document.querySelector('#book-demo')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToFeatures = () => {
    document.querySelector('#features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="home"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden"
    >
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse-glow" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1.5s' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8">
            <Zap className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">
              A Subsidiary of Forge Logic Design
            </span>
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight mb-6">
            <span className="text-gradient">{TAGLINES[currentTagline]}</span>
          </h1>

          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
            Southwest Automation Solutions provides AI-powered call and text assistants 
            that handle your scheduling, answer client questions, and keep your calendar 
            full — so you can focus on running your business.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <button
              onClick={scrollToBookDemo}
              className="group flex items-center gap-2 px-8 py-4 bg-primary text-primary-foreground rounded-xl font-semibold hover:bg-primary/90 transition-all glow-orange-sm"
            >
              Book a Demo
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={scrollToFeatures}
              className="px-8 py-4 border border-border text-foreground rounded-xl font-semibold hover:bg-muted transition-all"
            >
              See How It Works
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {STATS.map((stat, i) => (
              <div
                key={stat.label}
                className="p-4 rounded-xl bg-card/50 border border-border backdrop-blur-sm transition-all duration-700 hover:border-primary/30 hover:bg-card/80"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <div className="text-2xl sm:text-3xl font-bold text-primary mb-1">
                  {stat.value}
                </div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Feature pills */}
          <div className="flex flex-wrap items-center justify-center gap-6 mt-12">
            {[
              { icon: Phone, label: 'AI Call Answering' },
              { icon: MessageSquare, label: 'Text Messaging' },
              { icon: CalendarCheck, label: 'Smart Scheduling' },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2 text-muted-foreground">
                <Icon className="w-4 h-4 text-primary" />
                <span className="text-sm">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
