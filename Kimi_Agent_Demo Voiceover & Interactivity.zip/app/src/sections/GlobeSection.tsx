import { useEffect, useRef, useState } from 'react';
import { Brain, PhoneCall, MessageSquare, Calendar, Clock, Zap } from 'lucide-react';
import InteractiveGlobe from '../components/InteractiveGlobe';

const AI_CAPABILITIES = [
  [
    { metric: '10,000+', label: 'Calls answered daily', icon: PhoneCall },
    { metric: '50,000+', label: 'Texts sent monthly', icon: MessageSquare },
    { metric: '99.7%', label: 'Uptime reliability', icon: Clock },
  ],
  [
    { metric: '< 2s', label: 'Average response time', icon: Zap },
    { metric: '24/7', label: 'Always available', icon: Clock },
    { metric: '80%', label: 'No-show reduction', icon: Calendar },
  ],
];

const PROCESS_STEPS = [
  { step: '1', label: 'Call or text comes in', description: 'Customer reaches out any time of day' },
  { step: '2', label: 'AI answers instantly', description: 'Natural conversation, no hold times' },
  { step: '3', label: 'Schedule updated', description: 'Calendar syncs in real-time' },
  { step: '4', label: 'Confirmation sent', description: 'Text and email follow-up automatically' },
];

export default function GlobeSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeCap, setActiveCap] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const seed = Math.floor(Date.now() / 45000) % AI_CAPABILITIES.length;
    setActiveCap(seed);

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const capabilities = AI_CAPABILITIES[activeCap];

  return (
    <section ref={sectionRef} className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {/* Section Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Brain className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary font-medium">AI Intelligence Network</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="text-gradient">Powered by Advanced AI</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              This globe visualizes the neural network powering your AI assistant — 
              interconnected intelligence that routes calls, understands speech, and 
              manages your schedule seamlessly.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 items-center">
            {/* Stats sidebar */}
            <div className="space-y-6 order-2 lg:order-1">
              {capabilities.map((cap) => {
                const Icon = cap.icon;
                return (
                  <div
                    key={cap.label}
                    className="p-5 rounded-2xl bg-card/50 border border-border hover:border-primary/20 transition-all"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <Icon className="w-5 h-5 text-primary" />
                      <span className="text-sm text-muted-foreground">{cap.label}</span>
                    </div>
                    <div className="text-2xl font-bold text-primary">{cap.metric}</div>
                  </div>
                );
              })}

              {/* How it works */}
              <div className="p-5 rounded-2xl bg-card/50 border border-border">
                <h4 className="text-sm font-semibold text-foreground mb-4">How It Works</h4>
                <div className="space-y-3">
                  {PROCESS_STEPS.map((s) => (
                    <div key={s.step} className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-bold text-primary">{s.step}</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">{s.label}</p>
                        <p className="text-xs text-muted-foreground">{s.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Globe */}
            <div className="lg:col-span-2 order-1 lg:order-2">
              <div className="rounded-2xl bg-card/30 border border-border overflow-hidden">
                <InteractiveGlobe />
              </div>
              <p className="text-center text-xs text-muted-foreground mt-4">
                Drag to explore the AI neural network • Each node represents an active intelligence pathway
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
