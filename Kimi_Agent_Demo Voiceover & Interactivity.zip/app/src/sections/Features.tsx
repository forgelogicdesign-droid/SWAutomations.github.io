import { useEffect, useRef, useState } from 'react';
import {
  Phone,
  MessageSquare,
  CalendarCheck,
  Clock,
  Route,
  Voicemail,
  Bell,
  Languages,
  Users,
  Repeat,
  Shield,
} from 'lucide-react';

const FEATURE_SETS = [
  [
    { icon: Phone, title: 'AI Call Answering', description: 'Our AI answers every incoming call professionally, handles common questions, and routes urgent calls to the right person.' },
    { icon: MessageSquare, title: 'Text Confirmations', description: 'Automatically send SMS appointment reminders, confirmations, and follow-ups to reduce no-shows.' },
    { icon: CalendarCheck, title: 'Smart Scheduling', description: 'Clients book, reschedule, or cancel appointments by call or text — synced directly to your calendar.' },
    { icon: Clock, title: '24/7 Availability', description: 'Your AI assistant never takes a break. Capture leads and bookings around the clock, even on holidays.' },
    { icon: Route, title: 'Smart Call Routing', description: 'Urgent calls get forwarded instantly. Routine requests are handled automatically by the AI.' },
    { icon: Voicemail, title: 'Voicemail Transcription', description: 'Every voicemail is transcribed to text and sent to you instantly, so you read instead of listening.' },
  ],
  [
    { icon: Bell, title: 'Reminder Automation', description: 'Automated reminders via call and text reduce no-shows by up to 80% and keep your schedule full.' },
    { icon: Languages, title: 'Bilingual Support', description: 'Serve Spanish and English-speaking clients seamlessly with automatic language detection.' },
    { icon: Users, title: 'Multi-Staff Scheduling', description: 'Route appointments to the right team member based on availability, specialty, or client preference.' },
    { icon: Repeat, title: 'Recurring Appointments', description: 'Handle recurring bookings, package deals, and standing appointments without manual work.' },
    { icon: Shield, title: 'HIPAA-Compliant', description: 'Secure, encrypted communications that protect sensitive client information at all times.' },
    { icon: Clock, title: 'After-Hours Coverage', description: 'Capture every after-hours call and turn missed opportunities into booked appointments.' },
  ],
];

export default function Features() {
  const [activeSet, setActiveSet] = useState(0);
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set());
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const seed = Math.floor(Date.now() / 60000) % FEATURE_SETS.length;
    setActiveSet(seed);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute('data-index') || '0');
            setVisibleCards((prev) => new Set(prev).add(index));
          }
        });
      },
      { threshold: 0.2 }
    );

    const cards = sectionRef.current?.querySelectorAll('.feature-card');
    cards?.forEach((card) => observer.observe(card));

    return () => observer.disconnect();
  }, []);

  const features = FEATURE_SETS[activeSet];

  return (
    <section id="features" ref={sectionRef} className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            <span className="text-gradient">What Your AI Assistant Does</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            From answering calls to filling your calendar, your AI assistant handles 
            the communication tasks that eat up your day — so you don't have to.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => {
            const Icon = feature.icon;
            const isVisible = visibleCards.has(i);

            return (
              <div
                key={feature.title}
                data-index={i}
                className={`feature-card group p-6 rounded-2xl bg-card/50 border border-border backdrop-blur-sm cursor-default transition-all duration-500 hover:border-primary/40 hover:bg-card/80 hover:-translate-y-1 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Feature set tabs */}
        <div className="flex justify-center mt-10 gap-2">
          {FEATURE_SETS.map((_, i) => (
            <button
              key={i}
              onClick={() => setActiveSet(i)}
              className={`px-4 py-2 rounded-lg text-sm transition-all ${
                activeSet === i
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:text-foreground'
              }`}
            >
              {i === 0 ? 'Core Features' : 'More Features'}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
