import { useEffect, useRef, useState } from 'react';
import { MonitorPlay, Radio, MessageSquare, Phone } from 'lucide-react';
import AITypingDemo from '../components/AITypingDemo';

const DEMO_SCENARIOS = [
  {
    icon: Phone,
    title: 'Live Call Demo',
    description: 'Listen as our AI answers a real appointment call, checks availability, and books the slot — all in natural conversation.',
  },
  {
    icon: MessageSquare,
    title: 'Text Message Demo',
    description: 'Watch the AI handle a full text conversation: sending reminders, confirming appointments, and handling reschedules.',
  },
  {
    icon: Radio,
    title: 'After-Hours Demo',
    description: 'See how the AI captures every call after hours, routes emergencies, and books appointments while you sleep.',
  },
];

export default function Demo() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="demo" ref={sectionRef} className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <MonitorPlay className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary font-medium">Live AI Demo</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="text-gradient">See the AI in Action</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Watch and listen as our AI assistant handles real scheduling scenarios. 
              The voiceover narrates what the AI is thinking and typing in real-time.
            </p>
          </div>

          {/* Scenario cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {DEMO_SCENARIOS.map((scenario) => {
              const Icon = scenario.icon;
              return (
                <div
                  key={scenario.title}
                  className="p-5 rounded-xl bg-card/30 border border-border/50"
                >
                  <Icon className="w-8 h-8 text-primary mb-3" />
                  <h4 className="font-medium text-foreground mb-1">{scenario.title}</h4>
                  <p className="text-xs text-muted-foreground">{scenario.description}</p>
                </div>
              );
            })}
          </div>

          {/* AI Typing Demo */}
          <AITypingDemo />
        </div>
      </div>
    </section>
  );
}
