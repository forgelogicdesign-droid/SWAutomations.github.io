import { Link } from 'react-router-dom';
import { ArrowLeft, Shield, Mail, Phone } from 'lucide-react';
import ParticleNetwork from '../components/ParticleNetwork';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background relative">
      <ParticleNetwork />

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-md">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Legal</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Privacy Policy
          </h1>
          <p className="text-muted-foreground">
            Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </p>
        </div>

        <div className="space-y-8">
          <section className="p-6 rounded-2xl bg-card/50 border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-3">
              1. Introduction
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Southwest Automation Solutions ("we," "our," or "us"), a subsidiary of Forge Logic Design, 
              is committed to protecting your privacy. This Privacy Policy explains how we collect, use, 
              disclose, and safeguard your information when you visit our website or inquire about our 
              AI call and text assistant services.
            </p>
          </section>

          <section className="p-6 rounded-2xl bg-card/50 border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-3">
              2. Information We Collect
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-3">
              We may collect information about you in a variety of ways, including:
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span><strong className="text-foreground">Personal Data:</strong> Name, email address, phone number, company name, and other information you provide when booking a demo or contacting us.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span><strong className="text-foreground">Usage Data:</strong> Information about how you use our website, including pages visited, time spent, and demo interactions.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span><strong className="text-foreground">Technical Data:</strong> IP address, browser type, device information, and operating system for website improvement.</span>
              </li>
            </ul>
          </section>

          <section className="p-6 rounded-2xl bg-card/50 border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-3">
              3. How We Use Your Information
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-3">
              We use the information we collect to:
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Respond to your demo requests and inquiries about our AI assistant</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Schedule and conduct product demonstrations</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Send service updates, pricing information, and support messages</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Improve our AI assistant technology and website experience</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Comply with legal obligations and protect our rights</span>
              </li>
            </ul>
          </section>

          <section className="p-6 rounded-2xl bg-card/50 border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-3">
              4. Information Sharing
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              We do not sell, trade, or rent your personal information to third parties. 
              We may share information with trusted service providers who assist us in 
              operating our website and conducting our business, so long as those parties 
              agree to keep this information confidential.
            </p>
          </section>

          <section className="p-6 rounded-2xl bg-card/50 border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-3">
              5. Data Security
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              We implement appropriate technical and organizational security measures to 
              protect your personal information against unauthorized access, alteration, 
              disclosure, or destruction. However, no method of transmission over the Internet 
              is 100% secure, and we cannot guarantee absolute security.
            </p>
          </section>

          <section className="p-6 rounded-2xl bg-card/50 border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-3">
              6. Your Rights
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-3">
              Depending on your location, you may have the following rights regarding your personal data:
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Right to access the personal information we hold about you</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Right to request correction of inaccurate information</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Right to request deletion of your personal information</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Right to object to processing of your personal information</span>
              </li>
            </ul>
          </section>

          <section className="p-6 rounded-2xl bg-card/50 border border-border">
            <h2 className="text-xl font-semibold text-foreground mb-3">
              7. Contact Us
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              If you have any questions about this Privacy Policy, please contact us:
            </p>
            <div className="space-y-3">
              <a
                href="mailto:forgelogicdesign@gmail.com"
                className="flex items-center gap-3 p-3 rounded-xl bg-background border border-border hover:border-primary/30 transition-colors"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Email</p>
                  <p className="text-sm text-muted-foreground">forgelogicdesign@gmail.com</p>
                </div>
              </a>
              <a
                href="tel:5054808967"
                className="flex items-center gap-3 p-3 rounded-xl bg-background border border-border hover:border-primary/30 transition-colors"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Phone className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Phone</p>
                  <p className="text-sm text-muted-foreground">(505) 480-8967</p>
                </div>
              </a>
            </div>
          </section>
        </div>

        {/* Back to home */}
        <div className="mt-12 text-center">
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Homepage
          </Link>
        </div>
      </main>
    </div>
  );
}
