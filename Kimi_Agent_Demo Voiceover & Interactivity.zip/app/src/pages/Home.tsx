import ParticleNetwork from '../components/ParticleNetwork';
import Navbar from '../sections/Navbar';
import Hero from '../sections/Hero';
import Features from '../sections/Features';
import Demo from '../sections/Demo';
import GlobeSection from '../sections/GlobeSection';
import BookDemo from '../sections/BookDemo';
import Footer from '../sections/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-background relative">
      <ParticleNetwork />
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <Features />
        <Demo />
        <GlobeSection />
        <BookDemo />
      </main>
      <div className="relative z-10">
        <Footer />
      </div>
    </div>
  );
}
