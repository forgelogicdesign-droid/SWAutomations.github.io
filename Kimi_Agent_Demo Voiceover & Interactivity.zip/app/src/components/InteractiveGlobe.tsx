import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

function Globe() {
  const meshRef = useRef<THREE.Mesh>(null);
  const pointsRef = useRef<THREE.Points>(null);
  const arcsRef = useRef<THREE.LineSegments>(null);

  const globeRadius = 2;

  // Create dots on the globe surface
  const dotGeometry = useMemo(() => {
    const count = 3000;
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const color1 = new THREE.Color('#f97316');
    const color2 = new THREE.Color('#1e293b');
    const color3 = new THREE.Color('#fb923c');

    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count);
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;

      const x = globeRadius * Math.sin(phi) * Math.cos(theta);
      const y = globeRadius * Math.sin(phi) * Math.sin(theta);
      const z = globeRadius * Math.cos(phi);

      pos[i * 3] = x;
      pos[i * 3 + 1] = y;
      pos[i * 3 + 2] = z;

      const rand = Math.random();
      const c = rand < 0.3 ? color1 : rand < 0.7 ? color2 : color3;
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return geo;
  }, []);

  // Create connection arcs
  const arcGeometry = useMemo(() => {
    const arcs: number[] = [];
    const numArcs = 20;

    for (let i = 0; i < numArcs; i++) {
      const startLat = (Math.random() - 0.5) * Math.PI;
      const startLon = Math.random() * Math.PI * 2;
      const endLat = (Math.random() - 0.5) * Math.PI;
      const endLon = Math.random() * Math.PI * 2;

      const start = new THREE.Vector3(
        globeRadius * Math.cos(startLat) * Math.cos(startLon),
        globeRadius * Math.sin(startLat),
        globeRadius * Math.cos(startLat) * Math.sin(startLon)
      );
      const end = new THREE.Vector3(
        globeRadius * Math.cos(endLat) * Math.cos(endLon),
        globeRadius * Math.sin(endLat),
        globeRadius * Math.cos(endLat) * Math.sin(endLon)
      );

      const mid = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);
      mid.normalize().multiplyScalar(globeRadius * 1.4);

      const curve = new THREE.QuadraticBezierCurve3(start, mid, end);
      const points = curve.getPoints(30);

      for (let j = 0; j < points.length - 1; j++) {
        arcs.push(points[j].x, points[j].y, points[j].z);
        arcs.push(points[j + 1].x, points[j + 1].y, points[j + 1].z);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(arcs), 3));
    return geo;
  }, []);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.1;
    }
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.1;
    }
    if (arcsRef.current) {
      arcsRef.current.rotation.y = state.clock.elapsedTime * 0.1;
    }
  });

  return (
    <group>
      {/* Base sphere */}
      <mesh ref={meshRef}>
        <sphereGeometry args={[globeRadius, 64, 64]} />
        <meshBasicMaterial color="#0f172a" wireframe transparent opacity={0.3} />
      </mesh>

      {/* Outer glow sphere */}
      <mesh>
        <sphereGeometry args={[globeRadius * 1.02, 64, 64]} />
        <meshBasicMaterial
          color="#f97316"
          transparent
          opacity={0.05}
          side={THREE.BackSide}
        />
      </mesh>

      {/* Dots */}
      <points ref={pointsRef} geometry={dotGeometry}>
        <pointsMaterial
          size={0.02}
          vertexColors
          transparent
          opacity={0.8}
          sizeAttenuation
        />
      </points>

      {/* Connection arcs */}
      <lineSegments ref={arcsRef} geometry={arcGeometry}>
        <lineBasicMaterial color="#f97316" transparent opacity={0.4} />
      </lineSegments>
    </group>
  );
}

function Ring() {
  const ringRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (ringRef.current) {
      ringRef.current.rotation.x = Math.PI / 3;
      ringRef.current.rotation.z = state.clock.elapsedTime * 0.05;
    }
  });

  return (
    <mesh ref={ringRef}>
      <torusGeometry args={[3.2, 0.003, 16, 100]} />
      <meshBasicMaterial color="#f97316" transparent opacity={0.3} />
    </mesh>
  );
}

export default function InteractiveGlobe() {
  return (
    <div className="w-full h-[500px] md:h-[600px]">
      <Canvas camera={{ position: [0, 0, 7], fov: 45 }}>
        <ambientLight intensity={0.5} />
        <Globe />
        <Ring />
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          autoRotate
          autoRotateSpeed={0.5}
          minPolarAngle={Math.PI / 3}
          maxPolarAngle={Math.PI / 1.5}
        />
      </Canvas>
    </div>
  );
}
