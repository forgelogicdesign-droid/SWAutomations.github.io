import { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX } from 'lucide-react';

interface ScriptLine {
  text: string;
  delay: number; // ms before typing starts
  speed: number; // ms per character
}

interface ScriptInstance {
  title: string;
  voiceover: string;
  lines: ScriptLine[];
}

const SCRIPTS: ScriptInstance[] = [
  {
    title: 'Appointment Booking',
    voiceover: '/voiceover-1.mp3',
    lines: [
      { text: '> Southwest AI Assistant v2.4 initialized', delay: 0, speed: 30 },
      { text: '> Loading scheduling module...', delay: 600, speed: 25 },
      { text: '> Connected to calendar system', delay: 400, speed: 20 },
      { text: '', delay: 200, speed: 0 },
      { text: 'Hello! Thank you for calling.', delay: 500, speed: 40 },
      { text: 'I can help you book, reschedule, or cancel an appointment.', delay: 300, speed: 35 },
      { text: 'What would you like to do today?', delay: 400, speed: 35 },
      { text: '', delay: 200, speed: 0 },
      { text: '[Customer: I need to book a haircut for Friday]', delay: 1000, speed: 30 },
      { text: '', delay: 200, speed: 0 },
      { text: 'Perfect! I have openings Friday at 10 AM, 1 PM, or 3:30 PM.', delay: 600, speed: 35 },
      { text: 'Which time works best for you?', delay: 400, speed: 40 },
    ],
  },
  {
    title: 'Text Confirmation',
    voiceover: '/voiceover-2.mp3',
    lines: [
      { text: '> Southwest AI Assistant v2.4 initialized', delay: 0, speed: 30 },
      { text: '> Loading messaging module...', delay: 600, speed: 25 },
      { text: '> SMS gateway connected', delay: 400, speed: 20 },
      { text: '', delay: 200, speed: 0 },
      { text: 'Hi! This is Southwest Auto from Dr. Smith\'s office.', delay: 500, speed: 35 },
      { text: 'You have an appointment tomorrow, June 9th at 2:00 PM.', delay: 400, speed: 35 },
      { text: '', delay: 200, speed: 0 },
      { text: 'Reply CONFIRM to keep your appointment', delay: 600, speed: 35 },
      { text: 'Reply RESCHEDULE for other options', delay: 400, speed: 35 },
      { text: 'Reply CANCEL if you need to cancel', delay: 400, speed: 35 },
      { text: '', delay: 200, speed: 0 },
      { text: '[Customer replied: CONFIRM]', delay: 1200, speed: 30 },
      { text: '', delay: 200, speed: 0 },
      { text: 'Great! Your appointment is confirmed.', delay: 500, speed: 35 },
      { text: 'See you tomorrow at 2:00 PM!', delay: 400, speed: 40 },
    ],
  },
  {
    title: 'After-Hours Call Routing',
    voiceover: '/voiceover-3.mp3',
    lines: [
      { text: '> Southwest AI Assistant v2.4 initialized', delay: 0, speed: 30 },
      { text: '> Loading call routing module...', delay: 600, speed: 25 },
      { text: '> Voice recognition active', delay: 400, speed: 20 },
      { text: '> After-hours mode enabled', delay: 300, speed: 20 },
      { text: '', delay: 200, speed: 0 },
      { text: 'Hello! You\'ve reached us after hours.', delay: 500, speed: 35 },
      { text: 'I\'m your AI assistant and I\'m here to help.', delay: 400, speed: 35 },
      { text: '', delay: 200, speed: 0 },
      { text: 'Press 1 to schedule an appointment', delay: 600, speed: 35 },
      { text: 'Press 2 for prescription refills', delay: 400, speed: 35 },
      { text: 'Press 3 to leave an urgent message', delay: 400, speed: 35 },
      { text: 'Press 0 to hear these options again', delay: 400, speed: 35 },
      { text: '', delay: 200, speed: 0 },
      { text: '[Caller pressed: 3]', delay: 1200, speed: 30 },
      { text: '', delay: 200, speed: 0 },
      { text: 'I understand this is urgent.', delay: 500, speed: 35 },
      { text: 'Please describe your situation and I\'ll route it immediately.', delay: 400, speed: 35 },
    ],
  },
];

export default function AITypingDemo() {
  const [activeScript, setActiveScript] = useState(0);
  const [displayedLines, setDisplayedLines] = useState<string[]>([]);
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timeoutsRef = useRef<number[]>([]);

  const script = SCRIPTS[activeScript];

  // Reset everything when script changes
  const reset = useCallback(() => {
    timeoutsRef.current.forEach(clearTimeout);
    timeoutsRef.current = [];
    setDisplayedLines([]);
    setCurrentLineIndex(0);
    setCurrentCharIndex(0);
    setIsPlaying(false);
    setIsFinished(false);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  }, []);

  const handleScriptChange = (index: number) => {
    reset();
    setActiveScript(index);
  };

  // Typing effect
  useEffect(() => {
    if (!isPlaying || isFinished) return;

    const lines = script.lines;
    if (currentLineIndex >= lines.length) {
      setIsFinished(true);
      setIsPlaying(false);
      return;
    }

    const line = lines[currentLineIndex];

    if (currentCharIndex === 0) {
      // Wait for the line's delay before starting
      const delayTimeout = window.setTimeout(() => {
        setDisplayedLines((prev) => [...prev, '']);
      }, line.delay);
      timeoutsRef.current.push(delayTimeout);
      return;
    }

    if (currentCharIndex <= line.text.length) {
      const charTimeout = window.setTimeout(() => {
        setDisplayedLines((prev) => {
          const updated = [...prev];
          updated[updated.length - 1] = line.text.slice(0, currentCharIndex);
          return updated;
        });
        setCurrentCharIndex((prev) => prev + 1);
      }, line.speed);
      timeoutsRef.current.push(charTimeout);
    } else {
      // Line finished, move to next
      const nextTimeout = window.setTimeout(() => {
        setCurrentLineIndex((prev) => prev + 1);
        setCurrentCharIndex(0);
      }, 100);
      timeoutsRef.current.push(nextTimeout);
    }
  }, [isPlaying, isFinished, currentLineIndex, currentCharIndex, script]);

  // Start display lines when line index changes from 0 delay effect
  useEffect(() => {
    if (!isPlaying || isFinished) return;
    const line = script.lines[currentLineIndex];
    if (!line) return;

    if (currentCharIndex === 0 && line.text.length > 0) {
      // Trigger first character after delay
      const firstCharTimeout = window.setTimeout(() => {
        setCurrentCharIndex(1);
      }, line.delay);
      timeoutsRef.current.push(firstCharTimeout);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentLineIndex, isPlaying, isFinished]);

  // Start typing when play is clicked
  const togglePlay = () => {
    if (isFinished) {
      reset();
      setTimeout(() => setIsPlaying(true), 50);
      return;
    }
    setIsPlaying(!isPlaying);
  };

  // Handle audio
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio(script.voiceover);
    } else {
      audioRef.current.src = script.voiceover;
    }
    audioRef.current.muted = isMuted;

    if (isPlaying) {
      audioRef.current.play().catch(() => {});
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying, script, isMuted]);

  useEffect(() => {
    if (isFinished && audioRef.current) {
      audioRef.current.pause();
    }
  }, [isFinished]);

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Script selector */}
      <div className="flex flex-wrap gap-2 mb-4">
        {SCRIPTS.map((s, i) => (
          <button
            key={s.title}
            onClick={() => handleScriptChange(i)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeScript === i
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:text-foreground'
            }`}
          >
            {s.title}
          </button>
        ))}
      </div>

      {/* Terminal window */}
      <div className="rounded-xl overflow-hidden border border-border bg-[#0a0a0f] shadow-2xl">
        {/* Terminal header */}
        <div className="flex items-center gap-2 px-4 py-3 bg-[#111118] border-b border-border/50">
          <div className="w-3 h-3 rounded-full bg-red-500/80" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
          <div className="w-3 h-3 rounded-full bg-green-500/80" />
          <span className="ml-3 text-xs text-muted-foreground font-mono">
            southwest-ai-agent — {script.title.toLowerCase().replace(/\s/g, '-')}.demo
          </span>
        </div>

        {/* Terminal body */}
        <div className="p-4 sm:p-6 min-h-[320px] font-mono text-sm overflow-y-auto">
          {displayedLines.map((line, i) => (
            <div key={i} className="mb-1">
              {line.length === 0 ? (
                <br />
              ) : line.startsWith('[') && line.endsWith(']') ? (
                <span className="text-primary/70 italic">{line}</span>
              ) : line.startsWith('>') ? (
                <span className="text-emerald-400/80">{line}</span>
              ) : (
                <span className="text-orange-100/90">{line}</span>
              )}
              {i === displayedLines.length - 1 && isPlaying && (
                <span className="inline-block w-2 h-4 bg-primary ml-0.5 animate-pulse" />
              )}
            </div>
          ))}
          {displayedLines.length === 0 && (
            <div className="text-muted-foreground/50">
              <span className="inline-block w-2 h-4 bg-primary/50 mr-1 animate-pulse" />
              Waiting to start...
            </div>
          )}
          {isFinished && (
            <div className="mt-4 pt-4 border-t border-border/30">
              <span className="text-emerald-400/80 text-xs">
                {'>'} Demo complete. AI response generated in 1.2s
              </span>
            </div>
          )}
        </div>

        {/* Terminal controls */}
        <div className="flex items-center gap-3 px-4 py-3 bg-[#111118] border-t border-border/50">
          <button
            onClick={togglePlay}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" />
                Pause
              </>
            ) : isFinished ? (
              <>
                <RotateCcw className="w-4 h-4" />
                Replay
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                {displayedLines.length === 0 ? 'Run Demo' : 'Resume'}
              </>
            )}
          </button>

          <button
            onClick={() => setIsMuted(!isMuted)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted text-muted-foreground text-sm hover:text-foreground transition-colors"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <div className="flex-1" />

          {isFinished && (
            <span className="text-xs text-emerald-400/70">Completed</span>
          )}
          {isPlaying && (
            <span className="text-xs text-primary/70 animate-pulse">Running...</span>
          )}
        </div>
      </div>

      <p className="text-center text-xs text-muted-foreground mt-4">
        Voice narrates what the AI agent is typing — Different scenarios on each visit
      </p>
    </div>
  );
}
